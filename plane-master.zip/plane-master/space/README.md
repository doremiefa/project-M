<br /><br />

<p align="center">
<a href="https://plane.so">
  <img src="https://plane-marketing.s3.ap-south-1.amazonaws.com/plane-readme/plane_logo_.webp" alt="Plane Logo" width="70">
</a>
</p>

<h3 align="center"><b>Plane Space</b></h3>
<p align="center"><b>Open-source, self-hosted project planning tool</b></p>
