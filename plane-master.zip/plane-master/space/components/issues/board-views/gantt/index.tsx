export const IssueGanttView = () => <div> </div>;
