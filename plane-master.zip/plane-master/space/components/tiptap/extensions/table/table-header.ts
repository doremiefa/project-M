import { TableHeader as BaseTableHeader } from "@tiptap/extension-table-header";

const TableHeader = BaseTableHeader.extend({
  content: "paragraph",
});

export { TableHeader };
