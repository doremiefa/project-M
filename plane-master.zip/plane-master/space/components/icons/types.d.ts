export type Props = {
  width?: string | number;
  height?: string | number;
  color?: string;
  className?: string;
};
