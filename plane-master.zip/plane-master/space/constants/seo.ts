export const SITE_NAME = "Plane Deploy | Make your Plane boards and roadmaps pubic with just one-click. ";
export const SITE_TITLE = "Plane Deploy | Make your Plane boards public with one-click";
export const SITE_DESCRIPTION = "Plane Deploy is a customer feedback management tool built on top of plane.so";
export const SITE_KEYWORDS =
  "software development, customer feedback, software, accelerate, code management, release management, project management, issue tracking, agile, scrum, kanban, collaboration";
export const SITE_URL = "https://app.plane.so/";
export const TWITTER_USER_NAME = "planepowers";
