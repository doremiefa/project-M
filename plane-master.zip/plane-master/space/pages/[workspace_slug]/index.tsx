const WorkspaceProjectPage = () => (
  <div className="relative w-screen h-screen flex justify-center items-center text-5xl">Plane Workspace Space</div>
);

export default WorkspaceProjectPage;
