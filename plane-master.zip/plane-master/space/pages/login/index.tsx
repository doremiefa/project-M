import React from "react";

// components
import { LoginView } from "components/views";

const LoginPage = () => <LoginView />;

export default LoginPage;
