module.exports = {
  root: true,
  extends: ["custom"],
};
