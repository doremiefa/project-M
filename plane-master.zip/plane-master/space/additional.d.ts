// additional.d.ts
/// <reference types="next-images" />
