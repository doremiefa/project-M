#!/bin/sh
set -x

echo "Starting Plane Frontend.."
node $1
