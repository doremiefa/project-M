module.exports = require("tailwind-config-custom/postcss.config");
