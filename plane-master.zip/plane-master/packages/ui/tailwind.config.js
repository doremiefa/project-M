module.exports = require("tailwind-config-custom/tailwind.config");
