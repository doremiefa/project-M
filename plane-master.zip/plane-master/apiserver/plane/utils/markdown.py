import mistune

markdown = mistune.Markdown()